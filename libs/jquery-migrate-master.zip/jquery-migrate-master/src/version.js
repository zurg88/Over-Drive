
jQuery.migrateVersion = "3.0.2-pre";
